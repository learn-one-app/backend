'use strict';

module.exports = {
  art: {
    enable: true,
    package: 'egg-view-art',
  },
  mongoose: {
    enable: true,
    package: 'egg-mongoose',
  },
};
